import React, { Component } from 'react'
import { Link } from 'react-router-dom'

import IconButton from '@material-ui/core/IconButton';
import documentsData from '../../../data/documentsData.json'
import '../../../css/dashboard/documents.css'

export class documents extends Component {
    constructor(props){
        super(props);
        this.onChangeSearch = this.onChangeSearch.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handleKeyPress = this.handleKeyPress.bind(this);
        this.state = {
            currentPage: 0,
            originData: [],
            tableDatas: [],
            showDatas: [],
            search_value: "",
        }
    }
    componentDidMount(){

        this.props.selectLeftSidebar('dashboardState');

        this.setState({tableDatas: documentsData});
        this.setState({originData: documentsData});
        var temp = [];
        if(documentsData.length>10)
            temp = documentsData.slice(0, 10);
        else
            temp = documentsData.slice(0, documentsData.length);
        this.setState({showDatas: temp});
    }


    handlePagePrevious = () => {
        if(this.state.currentPage>0){
            this.setState({currentPage: this.state.currentPage - 1}, () => {
                var temp = [];
                if(this.state.tableDatas.length<10){
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                }
                else{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                }
                
            });
        }
    }

    handlePageNext = () => {
        if((this.state.currentPage*10 + 10) < this.state.tableDatas.length){
            var temp = [];
            if((this.state.currentPage*10 + 20) < this.state.tableDatas.length)
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                });
            else
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    console.log(this.state.tableDatas.length);
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                });
           
        }
    }

    handleSearch(){
        const {search_value} = this.state;
        var value = search_value.toLocaleLowerCase();
        var temp = this.state.originData.filter((object) => 
            {
                for (var key in object){
                    if(object[key].toLocaleLowerCase().indexOf(value)>-1)
                    return true;
                }
                return null;
            }
        );
        this.setState({tableDatas: temp}, ()=>{
            var tempdata = [];
            if(this.state.tableDatas.length<10){
                tempdata = this.state.tableDatas.slice(0, this.state.tableDatas.length);
                this.setState({showDatas: tempdata});
            }
            else{
                tempdata = this.state.tableDatas.slice(0, 10);
                this.setState({showDatas: tempdata});
            }
        });
    }

    onChangeSearch(e){
        this.setState({
            search_value: e.target.value
        })
    }

    handleKeyPress(e){
        if(e.key === "Enter")
            this.handleSearch();
    }

    render() {
        return (
            <div className="documents-whitelist-container animation-effect">
                <div className="documents-title-searchbox-contain">
                    <p className="dashboard-sub-title dark-blue">Documents</p>
                    <div>
                        <input type="text" value={this.state.search_value} onChange={this.onChangeSearch} onKeyPress={this.handleKeyPress} placeholder="Search here"></input>
                        <IconButton className="search-icon-btn" onClick={this.handleSearch}>
                            <i className="fa fa-search"></i>
                        </IconButton>
                    </div>
                </div>
                <div className="documents-whitelist-table-container">
                    <table className="documents-whitelist-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Files</th>
                                <th>Last Modified</th>
                                <th>Type</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.showDatas.map((data, i) => 
                            <tr key={i}>
                                <td className="folder-name-td">
                                    <Link to={'/dashboard/funding-portal'} className="link-style">
                                        <i className="fa fa-chevron-right"></i>
                                        <img src={'../../assets/icons/document.png'} alt="folder png"/>
                                        {data.name}
                                    </Link>
                                </td>
                                <td>{data.number}</td>
                                <td>{data.modified}&nbsp;Hours ago</td>
                                <td>{data.type}</td>
                                <td>
                                    <IconButton component="label">
                                        <i className="fa fa-cloud-upload"></i>
                                        <input
                                        type="file"
                                        name="file"
                                        style={{ display: "none" }} />
                                    </IconButton>
                                </td>
                            </tr>
                            )}
                        </tbody>
                    </table>
                </div>
                <div className="table-num-arrow-main">
                    {!this.state.showDatas.length>0 && (
                        <p>no folder</p>
                    )}
                </div>
                
                <div className="undo-btn-body">
                    <Link to={'/dashboard/assets'} className="link-style">
                        <IconButton component="label" className="undo-btn">
                            <i className="fa fa-undo"></i>
                        </IconButton>
                    </Link>
                </div>
            </div>
        )
    }
}

export default documents
