import React, { Component } from 'react'

export class index extends Component {
    componentDidMount(){
        this.props.selectLeftSidebar('bankingState');
    }
    render() {
        return (
            <div>
                banking here
            </div>
        )
    }
}

export default index
