import React, { Component } from 'react'
import Header from '../../components/common/Header/TopHeader';
import JoinForm from '../../components/homePage/JoinForm';
import Footer from '../../components/common/Footer';
import AssetsDetailContent from '../../components/assetsDetailPage/AssetsDetailContent';

export class index extends Component {
    render() {
        return (
            <div>
                <Header />

                <AssetsDetailContent />

                <JoinForm />
                
                <Footer />
            </div>
        )
    }
}

export default index
