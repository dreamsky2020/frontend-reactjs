import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './css/common.css';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';

import HomePage from './view/homepage'
import AboutUsPage from './view/aboutUs'
import AssetsDetailPage from './view/assetsDetailPage'
import RegisterPage from './view/registerPage'
import IssuerSignUpPage from './view/registerPage/IssuerSignUpPage'
import InvestorSignUpPage from './view/registerPage/InvestorSignUpPage'
import IssuerLoginPage from './view/registerPage/IssuerLoginPage'
import InvestorLoginPage from './view/registerPage/InvestorLoginPage'

// dashboard
import DashboardPage from './components/dashboard'


export class App extends Component {
  render() {
    return (
      <Router>
          <Switch>
              <Route exact path='/' component={ HomePage } />
              <Route path='/about-us' component={ AboutUsPage } />
              <Route path='/assets-detail' component={ AssetsDetailPage } />
              <Route path='/visitor-register' component={ RegisterPage } />
              <Route path='/issuer-sign-up' component={ IssuerSignUpPage } />
              <Route path='/investor-sign-up' component={ InvestorSignUpPage } />
              <Route path='/investor-log-in' component={ InvestorLoginPage } />
              <Route path='/issuer-log-in' component={ IssuerLoginPage } />



        {/* dashboard route */}
              <Route path='/dashboard/' component={ DashboardPage } />


          </Switch>
      </Router>
    )
  }
}
export default App
