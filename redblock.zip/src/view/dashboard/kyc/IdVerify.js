import React, { Component } from 'react'
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import IconButton from '@material-ui/core/IconButton';

import Select from "react-select";
import '../../../css/dashboard/id-verify.css'
const options1 = [
    { value: "serbia", label: "serbia" },
    { value: "china", label: "china" },
    { value: "unitestate", label: "unitestate" },
  ];


export class IdVerify extends Component {
    constructor(props) {
        super(props);

        this.state = {
            activeStep: 1,
            startDate:new Date(),
        }
    }

    componentDidMount(){
        this.props.selectLeftSidebar('kycState');
    }

    render() {
        const{startDate}=this.state;

        return (
            <div>

                <div className="id-verify-content animation-effect">
                   <div className="verify-header">
                       <h2>Being your ID Verification</h2>
                   </div>
                   <div className="verify-content">
                        <div className="verify-content-section1">
                            <div className="row col-12 verify-section-title">Personal details</div>
                            <div className="row verify-section1-content">
                                <div className="col-lg-6 col-md-6 col-sm-12 verify-section1-row">
                                    <div className="form-group ">
                                        <label>First Name</label>
                                        <input type="text" className="form-control"  required="" />
                                    </div>                                                       
                                </div>
                                <div className="col-lg-6 col-md-6 col-sm-12 verify-section1-row">
                                    <div className="form-group ">
                                        <label>Family Name</label>
                                        <input type="text" className="form-control"  required="" />
                                    </div>                                                       
                                </div>
                                <div className="col-lg-12 col-md-12 col-sm-12 verify-section1-row">
                                    <div className="form-group ">
                                        <label>Email Address</label>
                                        <input type="text" className="form-control"  required="" />
                                    </div>                                                       
                                </div>
                                <div className="col-lg-6 col-md-6 col-sm-12 verify-section1-row">
                                    <div className="form-group date-selet-input">
                                        <label>Data of Birth</label>
                                        <div className="input-group ">                                        
                                            <div className="input-group-prepend ">
                                                 <span className="input-group-text birthday-pre-span"><i className="fa fa-calendar-o" aria-hidden="true"></i></span>
                                            </div>                               
                                            <input type="text" className="form-control" name="#" />
                                        </div>
                                    </div>
                                        <div className="birthday-pic-calander">
                                            <DatePicker
                                                selected={startDate}
                                                onChange={date => this.setState(date)}
                                                // showTimeSelect
                                                // timeFormat="HH:mm"
                                                // timeIntervals={15}
                                                // timeCaption="time"
                                                dateFormat="MMMM d, yyyy"
                                                style={{zIndex: '100'}}                                                         
                                            />
                                        </div>                                           
                                </div>
                                <div className="col-lg-6 col-md-6 col-sm-12 verify-section1-row">
                                    <div className="form-group ">
                                        <label>Phone Number</label>
                                        <input type="text" className="form-control"  required="" />
                                    </div>                                                       
                                </div>
                            </div>

                            <div className="row col-12 verify-section-title top-space">Address</div>
                            <div className="row verify-section1-content">                                
                                <div className="col-lg-12 col-md-12 col-sm-12 verify-section1-row">
                                    <div className="form-group">
                                        <label>Street Address</label>
                                        <div className="input-group ">                                        
                                            <div className="input-group-prepend ">
                                                 <span className="input-group-text map-maker-pre"><i className="fa fa-map-marker"></i></span>
                                            </div>                               
                                            <input type="text" className="form-control" name="#" />
                                        </div>
                                    </div>                                  
                                </div>
                                <div className="col-lg-12 col-md-12 col-sm-12 verify-section1-row">
                                    <div className="form-group ">
                                        <label>Email Address</label>
                                        <input type="text" className="form-control"  required="" />
                                    </div>                                                       
                                </div>
                                <div className="col-lg-6 col-md-6 col-sm-12 verify-section1-row">
                                    <div className="form-group">
                                        <label>City</label>
                                        <div className="input-group ">                                        
                                            <div className="input-group-prepend ">
                                                 <span className="input-group-text map-maker-pre"><i className="fa fa-map-marker"></i></span>
                                            </div>                               
                                            <input type="text" className="form-control" name="#" />
                                        </div>
                                    </div>                                  
                                </div>
                                <div className="col-lg-6 col-md-6 col-sm-12 verify-section1-row">
                                    <div className="form-group">
                                        <label>Zipecode</label>
                                        <div className="input-group ">                                        
                                            <div className="input-group-prepend ">
                                                 <span className="input-group-text map-maker-pre"><i className="fa fa-map-marker"></i></span>
                                            </div>                               
                                            <input type="text" className="form-control" name="#" />
                                        </div>
                                    </div>                                  
                                </div>
                                <div className="col-lg-6 col-md-6 col-sm-12 verify-section1-row">
                                    <div className="form-group">
                                        <label>State</label>
                                        <div className="input-group ">                                        
                                            <div className="input-group-prepend ">
                                                 <span className="input-group-text map-maker-pre"><i className="fa fa-map-marker"></i></span>
                                            </div>                               
                                            <input type="text" className="form-control" name="#" />
                                        </div>
                                    </div>                                  
                                </div>
                                <div className="col-lg-6 col-md-6 col-sm-12 verify-section1-row">
                                    <div className="form-group">
                                        <label>Country</label>
                                        <Select options={options1} />
                                    </div>                                  
                                </div>
                            </div>
                        </div>   
                        <div className="verify-content-section2">
                            <div className="verify-section-title top-space">Upload Documents</div>
                            <div className="row verify-section2-content">
                                <div className="col-xl-6 col-md-12 col-sm-12 verify-section2-row">
                                    <div className="form-group">
                                        <label>Issuing Country</label>
                                        <Select options={options1} />
                                    </div>                                  
                                </div>
                                <div className="col-12"></div>
                                <div className="col-12 verify-section2-row big-top-space figure-row">
                                    <div className="figure-sub-parts">
                                        <div className="figure-parts">
                                            <div className="figure-part">
                                               
                                                    <div className="figure-img">
                                                        <img src={'../../assets/icons/passport.png'} alt='passport.png'></img>
                                                    </div>
                                                    <div className="figure-name">Passport</div>
                                                
                                            </div>
                                        </div> 
                                        <div className="figure-parts ">
                                            <div className="figure-part">
                                               
                                                    <div className="figure-img">
                                                        <img src={'../../assets/icons/passport.png'} alt='passport.png'></img>
                                                    </div>
                                                    <div className="figure-name">National Card</div>
                                                
                                            </div>
                                        </div> 
                                    </div>
                                    <div className="figure-sub-parts">
                                        <div className="figure-parts">
                                            <div className="figure-part">
                                               
                                                    <div className="figure-img">
                                                        <img src={'../../assets/icons/passport.png'} alt='passport.png'></img>
                                                    </div>
                                                    <div className="figure-name">Proof of Address</div>
                                               
                                            </div>
                                        </div>
                                        <div className="figure-parts">
                                            <div className="figure-part">
                                                
                                                    <div className="figure-img">
                                                        <img src={'../../assets/icons/passport.png'} alt='passport.png'></img>
                                                    </div>
                                                    <div className="figure-name">Selfie</div>
                                                
                                            </div>
                                        </div>
                                    </div>                                
                                </div>
                                <div className="col-md-12 verify-section-title big-top-space section2-blue-tilte">
                                    To avoid delays when verifying account, Please make sure bellow:
                                </div>
                                <div className="col-xl-12 col-md-12 col-sm-12 verify-section2-row avoid-content-line">
                                    <div className="check-circle-part">
                                         <img src={'../../assets/icons/circle-check.png'} alt='circle-check.png'></img>
                                    </div>
                                    <div className="avoid-content-txt"> Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam.</div>                                                                    
                                </div>
                                <div className="col-xl-12 col-md-12 col-sm-12 verify-section2-row avoid-content-line">
                                    <div className="check-circle-part"> 
                                        <img src={'../../assets/icons/circle-check.png'}  alt='circle-check.png'></img>
                                    </div>
                                    <div className="avoid-content-txt"> Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam.</div>                                                                    
                                </div>
                                <div className="col-xl-12 col-md-12 col-sm-12 verify-section2-row avoid-content-line">
                                    {/* <div className="check-circle-part"><span></span><i className="fa">&#xf00c;</i></div> */}
                                    <div className="check-circle-part"> 
                                        <img src={'../../assets/icons/circle-check.png'}  alt='circle-check.png'></img>
                                    </div>
                                    <div className="avoid-content-txt"> Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam.</div>                                                                    
                                </div>
                            </div>
                            <div className="verify-section-title gray-blue-txt big-top-space">Upload Here Your Passport Copy:</div>
                            <div className="passport-upload-section">
                                <div className="passport-upload-part1  col-xl-6 col-lg-7 col-md-9">
                                    <div className="upload-part1-section">
                                        <div className="pass-upload-icon">
                                            <IconButton component="label" className="upload-icon-btn">
                                                <i className="fa fa-cloud-upload"></i>
                                                <input
                                                    type="file"
                                                    name="media"
                                                    // accept=".doc, .docx,.ppt, .pptx,.txt,.pdf"
                                                    style={{ display: "none" }}
                                                />
                                            </IconButton>
                                        </div>
                                        <div className="pass-upload-txt">Drag your media files here or browse</div>
                                    </div>
                                </div>
                                <div className="passport-upload-part2">
                                    <div className="passport-sample-img"> <img src={'../../assets/icons/passportTemplate.png'} alt='passportTemplate.png'></img></div>
                                </div>
                            </div>
                            <div className="verify-prcess-button-section">
                                <button className="verify-prossess-btn red-btn-hover">Process to Verify</button>
                            </div>
                        </div>   
                    </div> 
               </div>

            </div>
        )
    }
}


export default IdVerify
